package com.linklyrics.core;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extracts the 22-char track id from a Spotify link or URI. */
public final class SpotifyLink {
    private static final Pattern URL =
        Pattern.compile("open\\.spotify\\.com/(?:intl-[a-zA-Z-]+/)?track/([A-Za-z0-9]{22})");
    private static final Pattern URI = Pattern.compile("spotify:track:([A-Za-z0-9]{22})");

    private SpotifyLink() {}

    public static String trackId(String input) {
        if (input == null) return null;
        String s = input.trim();
        Matcher m = URL.matcher(s);
        if (m.find()) return m.group(1);
        m = URI.matcher(s);
        if (m.find()) return m.group(1);
        return null;
    }
}
