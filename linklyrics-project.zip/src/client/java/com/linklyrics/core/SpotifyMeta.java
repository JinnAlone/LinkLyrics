package com.linklyrics.core;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads title / artist / duration from the public Spotify track page (no login needed). */
public final class SpotifyMeta {
    private static final String BROWSER_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
    private static final Pattern TITLE_TAG = Pattern.compile("<title>([^<]*)</title>");
    private static final Pattern SONG_BY = Pattern.compile("^(.*) - song(?: and lyrics)? by (.*?)\\s*\\|\\s*Spotify$");
    private static final Pattern NUM_ENT = Pattern.compile("&#(x?)([0-9a-fA-F]+);");

    private SpotifyMeta() {}

    public static TrackInfo fetch(String trackId) throws Exception {
        Http.Resp r = Http.get("https://open.spotify.com/track/" + trackId, BROWSER_UA);
        if (r.status() != 200) throw new Exception("Spotify trả về mã " + r.status());
        TrackInfo t = parse(r.body());
        if (t == null) throw new Exception("Không đọc được tên bài từ trang Spotify");
        return t;
    }

    /** Pure function so it can be tested without network. */
    public static TrackInfo parse(String html) {
        String title = null, artist = null;

        Matcher tt = TITLE_TAG.matcher(html);
        if (tt.find()) {
            Matcher m = SONG_BY.matcher(unescape(tt.group(1)).trim());
            if (m.matches()) { title = m.group(1).trim(); artist = m.group(2).trim(); }
        }
        if (title == null) title = meta(html, "og:title");
        if (artist == null) {
            String d = meta(html, "og:description");
            if (d != null) {
                int i = d.indexOf("on Spotify.");
                if (i >= 0) d = d.substring(i + "on Spotify.".length()).trim();
                String first = d.split(" · ")[0].trim();
                if (first.endsWith(".")) first = first.substring(0, first.length() - 1);
                if (!first.isEmpty()) artist = first;
            }
        }
        if (title == null || title.isBlank()) return null;

        double dur = -1;
        String ds = meta(html, "music:duration");
        if (ds != null) try { dur = Double.parseDouble(ds.trim()); } catch (NumberFormatException ignored) {}
        return new TrackInfo(title, artist == null ? "" : artist, dur);
    }

    private static String meta(String html, String key) {
        Matcher m = Pattern.compile("<meta\\s[^>]*?(?:property|name)=\"" + Pattern.quote(key) + "\"[^>]*>").matcher(html);
        if (!m.find()) return null;
        Matcher c = Pattern.compile("content=\"([^\"]*)\"").matcher(m.group());
        return c.find() ? unescape(c.group(1)) : null;
    }

    static String unescape(String s) {
        s = s.replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">");
        Matcher m = NUM_ENT.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            int cp = Integer.parseInt(m.group(2), m.group(1).isEmpty() ? 10 : 16);
            m.appendReplacement(sb, Matcher.quoteReplacement(new String(Character.toChars(cp))));
        }
        m.appendTail(sb);
        return sb.toString().replace("&amp;", "&");
    }
}
