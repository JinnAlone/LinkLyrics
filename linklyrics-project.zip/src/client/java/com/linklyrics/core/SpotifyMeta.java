package com.linklyrics.core;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads title / artist / duration from the public Spotify track page (no login needed). */
public final class SpotifyMeta {
    private static final String BROWSER_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";
    private static final Pattern TITLE_TAG = Pattern.compile("<title>([^<]*)</title>");
    private static final Pattern SONG_BY = Pattern.compile("^(.*) - song(?: and lyrics)? by (.*?)\\s*\\|\\s*Spotify$");
    private static final Pattern NUM_ENT = Pattern.compile("&#(x?)([0-9a-fA-F]+);");

    private SpotifyMeta() {}

    public static TrackInfo fetch(String trackId) throws Exception {
        String trackUrl = "https://open.spotify.com/track/" + trackId;
        StringBuilder why = new StringBuilder();
        String title = null, artist = null;
        double dur = -1;

        // 1) oEmbed: tiny JSON, reliable for the title
        try {
            Http.Resp r = Http.get("https://open.spotify.com/oembed?url="
                + URLEncoder.encode(trackUrl, StandardCharsets.UTF_8), BROWSER_UA);
            if (r.status() == 200) title = jsonString(r.body(), "title");
            else why.append("oembed=HTTP ").append(r.status()).append("; ");
        } catch (Exception e) { why.append("oembed=").append(e.getMessage()).append("; "); }

        // 2) embed page: has the artist list and duration in its embedded JSON
        try {
            Http.Resp r = Http.get("https://open.spotify.com/embed/track/" + trackId, BROWSER_UA);
            if (r.status() == 200) {
                String a = embedArtist(r.body());
                if (a != null) artist = a;
                double d = embedDuration(r.body());
                if (d > 0) dur = d;
                if (title == null) title = jsonString(r.body(), "title");
            } else why.append("embed=HTTP ").append(r.status()).append("; ");
        } catch (Exception e) { why.append("embed=").append(e.getMessage()).append("; "); }

        // 3) the normal track page (meta tags), as a last resort
        if (title == null || artist == null) {
            try {
                Http.Resp r = Http.get(trackUrl, BROWSER_UA);
                if (r.status() == 200) {
                    TrackInfo t = parse(r.body());
                    if (t != null) {
                        if (title == null) title = t.title();
                        if (artist == null && !t.artist().isEmpty()) artist = t.artist();
                        if (dur <= 0) dur = t.durationSec();
                    }
                } else why.append("page=HTTP ").append(r.status()).append("; ");
            } catch (Exception e) { why.append("page=").append(e.getMessage()).append("; "); }
        }

        if (title == null || title.isBlank())
            throw new Exception("Không đọc được tên bài từ Spotify (" + why + ")");
        return new TrackInfo(title.trim(), artist == null ? "" : artist.trim(), dur);
    }

    // ---- small JSON helpers (regex based, so they work without a JSON library) ----

    /** Value of the first "key":"..." string in the text, JSON-unescaped, or null. */
    static String jsonString(String text, String key) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(text);
        return m.find() ? jsonUnescape(m.group(1)) : null;
    }

    /** Artists from "artists":[{"name":"A"},{"name":"B"}] (or "subtitle":"A") in the embed page. */
    static String embedArtist(String text) {
        Matcher m = Pattern.compile("\"artists\"\\s*:\\s*\\[(.*?)]", Pattern.DOTALL).matcher(text);
        if (m.find()) {
            Matcher n = Pattern.compile("\"name\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(m.group(1));
            StringBuilder sb = new StringBuilder();
            while (n.find()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(jsonUnescape(n.group(1)));
            }
            if (sb.length() > 0) return sb.toString();
        }
        return jsonString(text, "subtitle");
    }

    /** Duration in seconds from "duration":213573 (ms) or "duration_ms"; -1 if absent. */
    static double embedDuration(String text) {
        for (String key : new String[] {"duration_ms", "durationMs", "duration"}) {
            Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*(\\d+)").matcher(text);
            if (m.find()) {
                double v = Double.parseDouble(m.group(1));
                return v > 1000 ? v / 1000.0 : v;
            }
        }
        return -1;
    }

    static String jsonUnescape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '\\' || i + 1 >= s.length()) { sb.append(c); continue; }
            char n = s.charAt(++i);
            switch (n) {
                case 'n' -> sb.append(' ');
                case 't' -> sb.append(' ');
                case 'u' -> {
                    if (i + 4 < s.length()) {
                        sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                        i += 4;
                    }
                }
                default -> sb.append(n); // \" \\ \/
            }
        }
        return sb.toString();
    }

    /** Pure function so it can be tested without network. */
    public static TrackInfo parse(String html) {
        String title = null, artist = null;

        Matcher tt = TITLE_TAG.matcher(html);
        if (tt.find()) {
            Matcher m = SONG_BY.matcher(unescape(tt.group(1)).trim());
            if (m.matches()) { title = m.group(1).trim(); artist = m.group(2).trim(); }
        }
        if (title == null) title = meta(html, "og:title");
        if (artist == null) {
            String d = meta(html, "og:description");
            if (d != null) {
                int i = d.indexOf("on Spotify.");
                if (i >= 0) d = d.substring(i + "on Spotify.".length()).trim();
                String first = d.split(" · ")[0].trim();
                if (first.endsWith(".")) first = first.substring(0, first.length() - 1);
                if (!first.isEmpty()) artist = first;
            }
        }
        if (title == null || title.isBlank()) return null;

        double dur = -1;
        String ds = meta(html, "music:duration");
        if (ds != null) try { dur = Double.parseDouble(ds.trim()); } catch (NumberFormatException ignored) {}
        return new TrackInfo(title, artist == null ? "" : artist, dur);
    }

    private static String meta(String html, String key) {
        Matcher m = Pattern.compile("<meta\\s[^>]*?(?:property|name)=\"" + Pattern.quote(key) + "\"[^>]*>").matcher(html);
        if (!m.find()) return null;
        Matcher c = Pattern.compile("content=\"([^\"]*)\"").matcher(m.group());
        return c.find() ? unescape(c.group(1)) : null;
    }

    static String unescape(String s) {
        s = s.replace("&quot;", "\"").replace("&lt;", "<").replace("&gt;", ">");
        Matcher m = NUM_ENT.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            int cp = Integer.parseInt(m.group(2), m.group(1).isEmpty() ? 10 : 16);
            m.appendReplacement(sb, Matcher.quoteReplacement(new String(Character.toChars(cp))));
        }
        m.appendTail(sb);
        return sb.toString().replace("&amp;", "&");
    }
}
