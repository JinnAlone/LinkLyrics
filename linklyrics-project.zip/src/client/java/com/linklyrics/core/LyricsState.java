package com.linklyrics.core;

import java.util.List;

/** Shared playback clock. A link has no playback position, so the mod keeps its own timer. */
public final class LyricsState {
    private static volatile List<Lrc.Line> lines = List.of();
    private static volatile String title = "";
    private static volatile boolean running;
    private static volatile double baseSec;
    private static volatile long baseNanos;
    /** Fine-tune sync, in seconds (positive = lyrics appear earlier). */
    public static volatile double offset = 0;

    private LyricsState() {}

    public static List<Lrc.Line> lines() { return lines; }
    public static String title() { return title; }
    public static boolean running() { return running; }

    public static synchronized void load(String name, List<Lrc.Line> l) {
        title = name; lines = l; baseSec = 0; baseNanos = System.nanoTime(); running = true;
    }

    public static synchronized void stop() { lines = List.of(); title = ""; running = false; }

    private static double raw() {
        return running ? baseSec + (System.nanoTime() - baseNanos) / 1e9 : baseSec;
    }

    public static double position() { return raw() + offset; }

    public static synchronized void pause() { baseSec = raw(); running = false; }
    public static synchronized void resume() { baseNanos = System.nanoTime(); running = true; }
    public static synchronized void seek(double sec) { baseSec = Math.max(0, sec); baseNanos = System.nanoTime(); }

    /** Index of the last line whose time <= pos, or -1 before the first line. */
    public static int indexAt(double pos) {
        List<Lrc.Line> l = lines;
        int lo = 0, hi = l.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (l.get(mid).time() <= pos) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }
}
