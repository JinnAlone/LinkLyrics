package com.linklyrics.core;

public record TrackInfo(String title, String artist, double durationSec) {}
