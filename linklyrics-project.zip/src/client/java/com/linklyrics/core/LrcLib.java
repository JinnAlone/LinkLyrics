package com.linklyrics.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Finds synced lyrics on LRCLIB (https://lrclib.net). */
public final class LrcLib {
    private static final String UA = "LinkLyrics/1.0 (Minecraft Fabric mod)";
    private static final String BASE = "https://lrclib.net/api/";

    private LrcLib() {}

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    public static String findSynced(TrackInfo t) throws Exception {
        String artist = t.artist().split(",")[0].trim();

        String[] searches;
        if (!artist.isEmpty()) {
            // 1) exact lookup
            String url = BASE + "get?track_name=" + enc(t.title()) + "&artist_name=" + enc(artist);
            if (t.durationSec() > 0) url += "&duration=" + Math.round(t.durationSec());
            Http.Resp r = Http.get(url, UA);
            if (r.status() == 200) {
                String s = synced(JsonParser.parseString(r.body()));
                if (s != null) return s;
            }
            // 2) structured search, then 3) free-text search
            searches = new String[] {
                BASE + "search?track_name=" + enc(t.title()) + "&artist_name=" + enc(artist),
                BASE + "search?q=" + enc((t.title() + " " + artist).trim())
            };
        } else {
            // artist unknown: free-text search by title only
            searches = new String[] { BASE + "search?q=" + enc(t.title()) };
        }
        for (String u : searches) {
            Http.Resp sr = Http.get(u, UA);
            if (sr.status() != 200) continue;
            JsonElement root = JsonParser.parseString(sr.body());
            if (!root.isJsonArray()) continue;
            String best = null;
            double bestDiff = Double.MAX_VALUE;
            for (JsonElement e : (JsonArray) root) {
                String s = synced(e);
                if (s == null) continue;
                double diff = 0;
                JsonObject o = e.getAsJsonObject();
                if (t.durationSec() > 0 && o.has("duration") && !o.get("duration").isJsonNull()) {
                    diff = Math.abs(o.get("duration").getAsDouble() - t.durationSec());
                }
                if (diff < bestDiff) { bestDiff = diff; best = s; }
            }
            if (best != null) return best;
        }
        throw new Exception("Không tìm thấy lời đồng bộ cho bài này trên LRCLIB");
    }

    private static String synced(JsonElement e) {
        if (e == null || !e.isJsonObject()) return null;
        JsonElement s = e.getAsJsonObject().get("syncedLyrics");
        if (s == null || s.isJsonNull()) return null;
        String str = s.getAsString();
        return str.isBlank() ? null : str;
    }
}
