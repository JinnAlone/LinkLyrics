package com.linklyrics.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parser for synced lyrics in LRC format: "[mm:ss.xx] text". */
public final class Lrc {
    public record Line(double time, String text) {}

    private static final Pattern STAMP = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");

    private Lrc() {}

    public static List<Line> parse(String lrc) {
        List<Line> out = new ArrayList<>();
        for (String raw : lrc.split("\\r?\\n")) {
            Matcher m = STAMP.matcher(raw);
            List<Double> times = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                double t = Integer.parseInt(m.group(1)) * 60.0 + Integer.parseInt(m.group(2));
                String f = m.group(3);
                if (f != null) t += Integer.parseInt(f) / Math.pow(10, f.length());
                times.add(t);
                end = m.end();
            }
            if (times.isEmpty()) continue;
            String text = raw.substring(end).trim();
            for (double t : times) out.add(new Line(t, text));
        }
        out.sort(Comparator.comparingDouble(Line::time));
        return out;
    }
}
