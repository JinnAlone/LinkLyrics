package com.linklyrics.client;

import com.linklyrics.core.LyricsState;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Paste a Spotify link here and press "Tải lời". */
final class SpotifyScreen extends PanelScreen {
    private EditBox box;
    private String message = "";

    SpotifyScreen(Screen parent) { super("Spotify link", parent); }

    @Override
    protected String status() {
        if (!message.isEmpty()) return message;
        return LyricsState.title().isEmpty() ? "Dán link bài hát Spotify rồi bấm Tải lời" : "Đang hiện: " + LyricsState.title();
    }

    @Override
    protected void buildButtons() {
        int w = colW() * 2 + 4;
        box = new EditBox(this.font, leftX(), rowY(1), w, 20, Component.literal("Link Spotify"));
        box.setMaxLength(400);
        this.addRenderableWidget(box);

        add("Tải lời từ link", leftX(), rowY(2), w, b -> LyricsLoader.load(box.getValue(), msg -> message = msg));
        add("Tạm dừng / Phát tiếp", leftX(), rowY(3), colW(), b -> {
            if (LyricsState.running()) LyricsState.pause(); else LyricsState.resume();
        });
        add("Dừng và xóa lời", rightX(), rowY(3), colW(), b -> { LyricsState.stop(); message = "Đã tắt lời."; });
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        g.text(this.font, "Link bài hát (open.spotify.com/track/...)", leftX(), rowY(1) - 11, 0xFFB8C4D8, false);
    }
}
