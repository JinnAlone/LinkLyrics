package com.linklyrics.client;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Common layout for the settings screens: title, status line, two columns of buttons, Done. */
abstract class PanelScreen extends Screen {
    protected final Screen parent;

    protected PanelScreen(String title, Screen parent) {
        super(Component.literal(title));
        this.parent = parent;
    }

    protected int colW() { return Math.min(150, (this.width - 24) / 2); }
    protected int leftX() { return this.width / 2 - colW() - 2; }
    protected int rightX() { return this.width / 2 + 2; }
    protected int rowY(int row) { return 52 + row * 24; }
    protected int bottomY() { return Math.max(rowY(6), this.height - 30); }

    protected abstract void buildButtons();
    protected String status() { return ""; }

    @Override
    protected void init() {
        buildButtons();
        addDone();
    }

    protected void addDone() {
        Button done = Button.builder(Component.literal("Xong"), b -> onClose())
            .bounds(rightX(), bottomY(), colW(), 20).build();
        this.addRenderableWidget(done);
    }

    protected Button add(String label, int x, int y, int w, Consumer<Button> action) {
        Button b = Button.builder(Component.literal(label), btn -> action.accept(btn)).bounds(x, y, w, 20).build();
        this.addRenderableWidget(b);
        return b;
    }

    /** A button whose label is recomputed after every click. */
    protected Button cycle(int x, int y, Supplier<String> label, Runnable advance) {
        Button b = Button.builder(Component.literal(label.get()), btn -> {
            advance.run();
            btn.setMessage(Component.literal(label.get()));
            Settings.save();
        }).bounds(x, y, colW(), 20).build();
        this.addRenderableWidget(b);
        return b;
    }

    @Override
    public void onClose() {
        this.minecraft.gui.setScreen(parent);
    }

    public boolean isPauseScreen() { return false; }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);

        if (Settings.get().glass) { // thin frosted frame; drawn around (not over) the buttons
            int x0 = leftX() - 10, x1 = rightX() + colW() + 10, y0 = 18, y1 = this.height - 6;
            g.fill(x0, y0, x1, y0 + 1, 0x70FFFFFF);
            g.fill(x0, y1 - 1, x1, y1, 0x40FFFFFF);
            g.fill(x0, y0, x0 + 1, y1, 0x50FFFFFF);
            g.fill(x1 - 1, y0, x1, y1, 0x50FFFFFF);
            g.fill(x0 + 1, y0 + 1, x1 - 1, 46, 0x1EFFFFFF);
        }

        String t = this.title.getString();
        int tw = this.font.width(t);
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate(this.width / 2f, 24f);
        pose.scale(1.5f, 1.5f);
        g.text(this.font, t, -tw / 2, 0, 0xFFFFFFFF, true);
        pose.popMatrix();

        String st = status();
        if (!st.isEmpty()) {
            while (st.length() > 4 && this.font.width(st) > this.width - 24) st = st.substring(0, st.length() - 2);
            g.text(this.font, st, this.width / 2 - this.font.width(st) / 2, 38, 0xFFB8C4D8, false);
        }
    }

    // ---- small helpers for option lists ----
    protected static int nearest(double[] values, double cur) {
        int best = 0;
        for (int i = 1; i < values.length; i++)
            if (Math.abs(values[i] - cur) < Math.abs(values[best] - cur)) best = i;
        return best;
    }
}
