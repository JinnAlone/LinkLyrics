package com.linklyrics.client;

import net.minecraft.client.gui.screens.Screen;

final class PlacementScreen extends PanelScreen {
    private static final String[] MODES = {"both", "world", "hud"};
    private static final String[] MODE_N = {"Cả hai", "Thế giới", "HUD"};
    private static final double[] DIST = {2.5, 3.5, 4.5, 6.0};
    private static final double[] SIZE = {0.7, 1.0, 1.4, 1.8, 2.4};
    private static final double[] HUDY = {0.55, 0.65, 0.74, 0.84};

    PlacementScreen(Screen parent) { super("Placement", parent); }

    @Override
    protected String status() { return "Chữ hiện ở đâu và to cỡ nào"; }

    @Override
    protected void buildButtons() {
        Settings s = Settings.get();
        cycle(leftX(), rowY(0), () -> "Chế độ: " + MODE_N[modeIndex(s)],
            () -> s.mode = MODES[(modeIndex(s) + 1) % MODES.length]);
        cycle(rightX(), rowY(0), () -> "Khoảng cách: " + DIST[nearest(DIST, s.distance)],
            () -> s.distance = DIST[(nearest(DIST, s.distance) + 1) % DIST.length]);
        cycle(leftX(), rowY(1), () -> "Cỡ chữ: " + SIZE[nearest(SIZE, s.scale)],
            () -> s.scale = SIZE[(nearest(SIZE, s.scale) + 1) % SIZE.length]);
        cycle(rightX(), rowY(1), () -> "Độ cao HUD: " + (int) Math.round(HUDY[nearest(HUDY, s.hudY)] * 100) + "%",
            () -> s.hudY = HUDY[(nearest(HUDY, s.hudY) + 1) % HUDY.length]);
    }

    private static int modeIndex(Settings s) {
        for (int i = 0; i < MODES.length; i++) if (MODES[i].equals(s.mode)) return i;
        return 0;
    }
}
