package com.linklyrics.client;

import com.linklyrics.core.Lrc;
import com.linklyrics.core.LyricsState;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

/**
 * Draws lyrics two ways, both through the HUD draw call (no custom 3D rendering):
 *  - HUD mode: previous / current / next line at the bottom of the screen.
 *  - World mode: each line gets a fixed point in the world around the player; every frame that
 *    point is projected to the screen with the player's view, so the text stays in place when
 *    you turn or walk and gets smaller with distance. (No depth test: text shows through walls.)
 */
public final class LyricsView implements HudElement {
    private static final double WORLD_TEXT_HEIGHT = 0.30; // blocks per text line
    private static final double FADE_OUT = 2.5;           // seconds

    private static final class Placed {
        final String text; final double x, y, z; final long born; long ended;
        Placed(String text, double x, double y, double z, long born) {
            this.text = text; this.x = x; this.y = y; this.z = z; this.born = born;
        }
    }

    private final List<Placed> placed = new ArrayList<>();
    private final Random rng = new Random();
    private List<Lrc.Line> lastLines = List.of();
    private int lastIdx = -2, counter = 0;
    private long idxSince = System.nanoTime();

    @Override
    public void render(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        List<Lrc.Line> lines = LyricsState.lines();
        if (p == null || lines.isEmpty()) { placed.clear(); lastLines = List.of(); return; }

        long now = System.nanoTime();
        int idx = LyricsState.indexAt(LyricsState.position());
        if (lines != lastLines) { placed.clear(); lastLines = lines; lastIdx = -2; }
        if (idx != lastIdx) {
            lastIdx = idx; idxSince = now;
            for (Placed pl : placed) if (pl.ended == 0) pl.ended = now;
            if (idx >= 0 && !lines.get(idx).text().isBlank()) spawn(p, lines.get(idx).text(), now);
        }
        placed.removeIf(pl -> pl.ended != 0 && (now - pl.ended) / 1e9 > FADE_OUT);

        Settings s = Settings.get();
        if (s.showWorld()) drawWorld(g, mc, p, dt, s, now);
        if (s.showHud()) drawHud(g, mc, lines, idx, s, now);
    }

    private void spawn(LocalPlayer p, String text, long now) {
        // spread lines left / centre / right of where the player is looking so they don't overlap
        double offsetDeg = ((counter++ % 3) - 1) * 38 + (rng.nextDouble() - 0.5) * 12;
        double a = Math.toRadians(p.getYRot() + offsetDeg);
        double d = 3.0 + rng.nextDouble() * 2.5;
        double x = p.getX() - Math.sin(a) * d;
        double z = p.getZ() + Math.cos(a) * d;
        double y = p.getEyeY() + (rng.nextDouble() - 0.4) * 1.4;
        placed.add(new Placed(text, x, y, z, now));
    }

    private void drawWorld(GuiGraphics g, Minecraft mc, LocalPlayer p, DeltaTracker dt, Settings s, long now) {
        float pt = dt.getGameTimeDeltaPartialTick(false);
        double yaw = Math.toRadians(p.getViewYRot(pt)), pitch = Math.toRadians(p.getViewXRot(pt));
        double cx = p.getX(), cy = p.getEyeY(), cz = p.getZ();
        // camera basis (Minecraft: yaw 0 faces +Z)
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

        int W = mc.getWindow().getGuiScaledWidth(), H = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) W / H;

        for (Placed pl : placed) {
            double dx = pl.x - cx, dy = pl.y - cy, dz = pl.z - cz;
            double z = dx * fx + dy * fy + dz * fz;
            if (z < 0.3) continue;
            double x = dx * rx + dy * ry + dz * rz;
            double y = dx * ux + dy * uy + dz * uz;
            double sx = W / 2.0 + (x / z) / (tanHalf * aspect) * (W / 2.0);
            double sy = H / 2.0 - (y / z) / tanHalf * (H / 2.0);
            if (sx < -300 || sx > W + 300 || sy < -100 || sy > H + 100) continue;

            double pxPerBlock = (H / 2.0) / (tanHalf * z);
            float scale = (float) Math.max(0.35, Math.min(3.5, pxPerBlock * WORLD_TEXT_HEIGHT * s.scale / 9.0));

            boolean active = pl.ended == 0;
            double age = (now - pl.born) / 1e9;
            float pop = (float) ease(Math.min(1, age / 0.30));
            float alpha = active ? pop : (float) Math.max(0, 1 - (now - pl.ended) / 1e9 / FADE_OUT) * 0.6f;
            float sc = scale * (active ? (0.7f + 0.3f * pop) : 1f);
            drawLine(g, mc, pl.text, (float) sx, (float) sy, sc, s.rgb(), alpha);
        }
    }

    private void drawHud(GuiGraphics g, Minecraft mc, List<Lrc.Line> lines, int idx, Settings s, long now) {
        int W = mc.getWindow().getGuiScaledWidth(), H = mc.getWindow().getGuiScaledHeight();
        float pop = (float) ease(Math.min(1, (now - idxSince) / 1e9 / 0.25));
        float base = (float) s.scale;
        float cy = H * 0.74f;
        if (idx - 1 >= 0) drawLine(g, mc, lines.get(idx - 1).text(), W / 2f, cy - 22 * base, 0.9f * base, s.rgb(), 0.35f);
        if (idx >= 0) drawLine(g, mc, lines.get(idx).text(), W / 2f, cy, (1.5f + 0.15f * pop) * base, s.rgb(), pop);
        if (idx + 1 < lines.size()) drawLine(g, mc, lines.get(idx + 1).text(), W / 2f, cy + 22 * base, 0.9f * base, s.rgb(), 0.45f);
    }

    private static void drawLine(GuiGraphics g, Minecraft mc, String text, float cx, float cy, float scale, int rgb, float alpha) {
        if (text == null || text.isBlank() || alpha <= 0.02f) return;
        Component c = Component.literal(text).withStyle(FontUtil.style());
        int w = mc.font.width(c);
        int a = Math.max(8, Math.min(255, (int) (alpha * 255)));
        var pose = g.pose();               // 2D matrix stack (1.21.6+)
        pose.pushMatrix();
        pose.translate(cx, cy);
        pose.scale(scale, scale);
        g.drawString(mc.font, c, -w / 2, -4, (a << 24) | rgb, true);
        pose.popMatrix();
    }

    private static double ease(double t) { return 1 - Math.pow(1 - t, 3); }
}
