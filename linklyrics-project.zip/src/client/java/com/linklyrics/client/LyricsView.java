package com.linklyrics.client;

import com.linklyrics.core.Lrc;
import com.linklyrics.core.LyricsState;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;

/**
 * Smooth animated lyrics, drawn through the HUD draw call.
 *  - Every word pops in with a springy overshoot, tinted with the accent colour, then settles.
 *  - World lines are anchored to points around the player, projected to the screen each frame,
 *    and gently float / sway. When replaced they drift up and fade.
 *  - Sparks burst from each revealed word.
 * Word timing is estimated from the line's duration (synced lyrics only have line timestamps).
 */
public final class LyricsView implements HudElement {
    private static final double WORLD_TEXT_HEIGHT = 0.30; // blocks per text line
    private static final float EXIT_SECONDS = 1.2f;

    private static final class Spring {
        float x, v;
        void step(float target, float k, float c, float dt) {
            int n = Math.max(1, (int) Math.ceil(dt / 0.008f));
            float h = dt / n;
            for (int i = 0; i < n; i++) {
                v += (k * (target - x) - c * v) * h;
                x += v * h;
            }
        }
    }

    private static final class Word {
        final String text; final double begin; long shown; final Spring pop = new Spring();
        Word(String text, double begin) { this.text = text; this.begin = begin; }
    }

    private static final class LineFx {
        final List<Word> words = new ArrayList<>();
        final double ax, ay, az; final long born; long ended; final float seed;
        final Spring rise = new Spring();
        LineFx(String text, double begin, double dur, boolean karaoke,
               double ax, double ay, double az, long born, float seed) {
            this.ax = ax; this.ay = ay; this.az = az; this.born = born; this.seed = seed;
            rise.x = -0.45f;
            String[] parts = text.trim().split("\\s+");
            int total = 0;
            for (String p : parts) total += p.length();
            int cum = 0;
            for (String p : parts) {
                double b = karaoke ? begin + dur * 0.8 * cum / Math.max(1, total) : begin;
                words.add(new Word(p, b));
                cum += p.length();
            }
        }
    }

    private static final class Spark {
        float x, y, vx, vy, life, max; int rgb;
    }

    private final List<LineFx> placed = new ArrayList<>();
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rng = new Random();
    private LineFx hudLine, hudOld;
    private List<Lrc.Line> lastLines = List.of();
    private int lastIdx = -2, counter = 0;
    private long lastNs = System.nanoTime();

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        Settings s = Settings.get();
        List<Lrc.Line> lines = LyricsState.lines();
        long now = System.nanoTime();
        float fdt = Math.min(0.05f, Math.max(0.001f, (now - lastNs) / 1e9f));
        lastNs = now;

        if (p == null || !s.enabled || lines.isEmpty()) {
            placed.clear(); sparks.clear(); hudLine = null; hudOld = null;
            lastLines = List.of(); lastIdx = -2;
            return;
        }

        double pos = LyricsState.position();
        int idx = LyricsState.indexAt(pos);
        if (lines != lastLines) {
            placed.clear(); sparks.clear(); hudLine = null; hudOld = null;
            lastLines = lines; lastIdx = -2;
        }
        if (idx != lastIdx) {
            lastIdx = idx;
            for (LineFx l : placed) if (l.ended == 0) l.ended = now;
            if (hudLine != null) { hudOld = hudLine; hudOld.ended = now; }
            hudLine = null;
            if (idx >= 0 && !lines.get(idx).text().isBlank()) {
                double begin = lines.get(idx).time();
                double next = idx + 1 < lines.size() ? lines.get(idx + 1).time() : begin + 4;
                double dur = Math.max(1.2, Math.min(8, next - begin));
                placed.add(spawn(p, lines.get(idx).text(), begin, dur, s, now));
                hudLine = new LineFx(lines.get(idx).text(), begin, dur, s.karaoke, 0, 0, 0, now, 0);
            }
        }
        placed.removeIf(l -> l.ended != 0 && (now - l.ended) / 1e9 > EXIT_SECONDS + 0.1);

        if (s.showWorld()) drawWorld(g, mc, p, dt, s, now, pos, fdt);
        if (s.showHud()) drawHud(g, mc, lines, idx, s, now, pos, fdt);
        drawSparks(g, fdt);
    }

    private LineFx spawn(LocalPlayer p, String text, double begin, double dur, Settings s, long now) {
        double offsetDeg = ((counter++ % 3) - 1) * 38 + (rng.nextDouble() - 0.5) * 12;
        double a = Math.toRadians(p.getYRot() + offsetDeg);
        double d = s.distance * (0.8 + rng.nextDouble() * 0.4);
        double x = p.getX() - Math.sin(a) * d;
        double z = p.getZ() + Math.cos(a) * d;
        double y = p.getEyeY() + (rng.nextDouble() - 0.4) * 1.3;
        return new LineFx(text, begin, dur, s.karaoke, x, y, z, now, rng.nextFloat() * 6.28f);
    }

    // ------------------------------------------------------------------ world

    private void drawWorld(GuiGraphicsExtractor g, Minecraft mc, LocalPlayer p, DeltaTracker dt,
                           Settings s, long now, double pos, float fdt) {
        float pt = dt.getGameTimeDeltaPartialTick(false);
        double yaw = Math.toRadians(p.getViewYRot(pt)), pitch = Math.toRadians(p.getViewXRot(pt));
        double cx = p.getX(), cy = p.getEyeY(), cz = p.getZ();
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
        double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

        int W = mc.getWindow().getGuiScaledWidth(), H = mc.getWindow().getGuiScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double aspect = (double) W / H;

        for (LineFx l : placed) {
            boolean active = l.ended == 0;
            l.rise.step(active ? 0f : 0.9f, 38f, 9f, fdt);
            double t = (now - l.born) / 1e9;
            double sway = Math.sin(t * 0.9 + l.seed * 1.7) * 0.05 * s.bob;
            double bob = Math.sin(t * 1.4 + l.seed) * 0.05 * s.bob;
            double dx = l.ax + sway - cx, dy = l.ay + l.rise.x + bob - cy, dz = l.az - cz;
            double z = dx * fx + dy * fy + dz * fz;
            if (z < 0.3) continue;
            double x = dx * rx + dy * ry + dz * rz;
            double y = dx * ux + dy * uy + dz * uz;
            double sx = W / 2.0 + (x / z) / (tanHalf * aspect) * (W / 2.0);
            double sy = H / 2.0 - (y / z) / tanHalf * (H / 2.0);
            if (sx < -300 || sx > W + 300 || sy < -100 || sy > H + 100) continue;

            double pxPerBlock = (H / 2.0) / (tanHalf * z);
            float scale = (float) Math.max(0.35, Math.min(3.5, pxPerBlock * WORLD_TEXT_HEIGHT * s.scale / 9.0));
            float alpha = active ? 1f : (float) Math.max(0, 1 - (now - l.ended) / 1e9 / EXIT_SECONDS);
            drawLine(g, mc, l, (float) sx, (float) sy, scale, alpha, pos, now, fdt, s);
        }
    }

    // ------------------------------------------------------------------ hud

    private void drawHud(GuiGraphicsExtractor g, Minecraft mc, List<Lrc.Line> lines, int idx,
                         Settings s, long now, double pos, float fdt) {
        int W = mc.getWindow().getGuiScaledWidth(), H = mc.getWindow().getGuiScaledHeight();
        float base = (float) s.scale;
        float cy = (float) (H * s.hudY);

        if (hudOld != null) {
            float prog = (float) ((now - hudOld.ended) / 1e9 / 0.5);
            if (prog >= 1f) hudOld = null;
            else drawLine(g, mc, hudOld, W / 2f, cy - 16 * base * prog, 1.5f * base, 1f - prog, pos, now, fdt, s);
        }
        if (hudLine != null) drawLine(g, mc, hudLine, W / 2f, cy, 1.5f * base, 1f, pos, now, fdt, s);

        if (idx + 1 < lines.size() && !lines.get(idx + 1).text().isBlank()) {
            drawPlain(g, mc, lines.get(idx + 1).text(), W / 2f, cy + 24 * base, 0.9f * base, 0.4f, s.rgb());
        }
    }

    // ------------------------------------------------------------------ drawing helpers

    private void drawLine(GuiGraphicsExtractor g, Minecraft mc, LineFx l, float cx, float cy, float scale,
                          float alphaMul, double pos, long now, float fdt, Settings s) {
        var style = FontUtil.style();
        float space = mc.font.width(Component.literal(" ").withStyle(style));
        float[] widths = new float[l.words.size()];
        float total = 0;
        for (int i = 0; i < widths.length; i++) {
            widths[i] = mc.font.width(Component.literal(l.words.get(i).text).withStyle(style));
            total += widths[i] + (i > 0 ? space : 0);
        }
        float sp = (float) s.speed;
        float k = 190f * sp * sp;
        float c = 2f * (float) Math.sqrt(k) * 0.48f; // under-damped: small overshoot
        int base = s.rgb(), accent = s.accentRgb();

        float cursor = -total / 2f;
        for (int i = 0; i < widths.length; i++) {
            Word w = l.words.get(i);
            float wcx = cx + (cursor + widths[i] / 2f) * scale;
            cursor += widths[i] + space;

            boolean reveal = pos >= w.begin;
            if (reveal && w.shown == 0) {
                w.shown = now;
                if (s.sparks && l.ended == 0) burst(wcx, cy, accent);
            }
            w.pop.step(reveal ? 1f : 0f, k, c, fdt);
            float pop = w.pop.x;
            if (pop < 0.02f) continue;

            float ws = scale * Math.min(1.25f, pop);
            float a = Math.max(0f, Math.min(1f, pop)) * alphaMul;
            float age = w.shown == 0 ? 1f : (now - w.shown) / 1e9f;
            int rgb = lerp(accent, base, Math.min(1f, age / 0.6f));
            Component comp = Component.literal(w.text).withStyle(style);
            int x0 = -(int) (widths[i] / 2f);

            var pose = g.pose();
            pose.pushMatrix();
            pose.translate(wcx, cy);
            pose.scale(ws, ws);
            if (s.glow) {
                int ga = argb(a * 0.22f, accent);
                g.text(mc.font, comp, x0 - 1, -4, ga, false);
                g.text(mc.font, comp, x0 + 1, -4, ga, false);
                g.text(mc.font, comp, x0, -5, ga, false);
                g.text(mc.font, comp, x0, -3, ga, false);
            }
            g.text(mc.font, comp, x0, -4, argb(a, rgb), true);
            pose.popMatrix();
        }
    }

    private void drawPlain(GuiGraphicsExtractor g, Minecraft mc, String text, float cx, float cy,
                           float scale, float alpha, int rgb) {
        Component comp = Component.literal(text).withStyle(FontUtil.style());
        int w = mc.font.width(comp);
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate(cx, cy);
        pose.scale(scale, scale);
        g.text(mc.font, comp, -w / 2, -4, argb(alpha, rgb), true);
        pose.popMatrix();
    }

    private void burst(float x, float y, int rgb) {
        if (sparks.size() > 160) return;
        for (int i = 0; i < 4; i++) {
            Spark sp = new Spark();
            double a = rng.nextDouble() * Math.PI * 2;
            float speed = 18f + rng.nextFloat() * 42f;
            sp.x = x; sp.y = y;
            sp.vx = (float) Math.cos(a) * speed;
            sp.vy = (float) Math.sin(a) * speed - 18f;
            sp.max = sp.life = 0.45f + rng.nextFloat() * 0.5f;
            sp.rgb = rng.nextInt(3) == 0 ? 0xFFFFFF : rgb;
            sparks.add(sp);
        }
    }

    private void drawSparks(GuiGraphicsExtractor g, float fdt) {
        for (Iterator<Spark> it = sparks.iterator(); it.hasNext(); ) {
            Spark sp = it.next();
            sp.life -= fdt;
            if (sp.life <= 0) { it.remove(); continue; }
            sp.vy += 70f * fdt;
            sp.x += sp.vx * fdt;
            sp.y += sp.vy * fdt;
            int a = (int) (255 * Math.max(0, sp.life / sp.max));
            int size = sp.max > 0.7f ? 2 : 1;
            int ix = (int) sp.x, iy = (int) sp.y;
            g.fill(ix, iy, ix + size, iy + size, (Math.max(8, a) << 24) | sp.rgb);
        }
    }

    private static int argb(float alpha, int rgb) {
        int a = Math.max(8, Math.min(255, (int) (alpha * 255)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int lerp(int from, int to, float t) {
        int r = (int) (((from >> 16) & 255) * (1 - t) + ((to >> 16) & 255) * t);
        int gr = (int) (((from >> 8) & 255) * (1 - t) + ((to >> 8) & 255) * t);
        int b = (int) ((from & 255) * (1 - t) + (to & 255) * t);
        return (r << 16) | (gr << 8) | b;
    }
}
