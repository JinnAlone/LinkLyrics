package com.linklyrics.client;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

import com.linklyrics.core.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class LyricsCommands {
    private LyricsCommands() {}

    private record Result(TrackInfo track, List<Lrc.Line> lines) {}

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(literal("lyrics")
            .then(literal("stop").executes(c -> { LyricsState.stop(); say(c.getSource(), "Đã tắt lời bài hát."); return 1; }))
            .then(literal("pause").executes(c -> { LyricsState.pause(); say(c.getSource(), "Tạm dừng."); return 1; }))
            .then(literal("resume").executes(c -> { LyricsState.resume(); say(c.getSource(), "Tiếp tục."); return 1; }))
            .then(literal("seek").then(argument("giay", DoubleArgumentType.doubleArg(0)).executes(c -> {
                LyricsState.seek(DoubleArgumentType.getDouble(c, "giay"));
                say(c.getSource(), "Đã tua tới giây " + DoubleArgumentType.getDouble(c, "giay")); return 1; })))
            .then(literal("offset").then(argument("giay", DoubleArgumentType.doubleArg(-30, 30)).executes(c -> {
                LyricsState.offset = DoubleArgumentType.getDouble(c, "giay"); Settings.save();
                say(c.getSource(), "Độ lệch: " + LyricsState.offset + "s (số dương = lời hiện sớm hơn)"); return 1; })))
            .then(literal("mode")
                .then(literal("world").executes(c -> mode(c.getSource(), "world")))
                .then(literal("hud").executes(c -> mode(c.getSource(), "hud")))
                .then(literal("both").executes(c -> mode(c.getSource(), "both"))))
            .then(literal("font").then(argument("id", StringArgumentType.greedyString()).executes(c -> {
                Settings.get().font = StringArgumentType.getString(c, "id").trim(); Settings.save();
                say(c.getSource(), "Font: " + Settings.get().font); return 1; })))
            .then(literal("scale").then(argument("v", DoubleArgumentType.doubleArg(0.3, 4)).executes(c -> {
                Settings.get().scale = DoubleArgumentType.getDouble(c, "v"); Settings.save();
                say(c.getSource(), "Cỡ chữ: " + Settings.get().scale); return 1; })))
            .then(literal("color").then(argument("hex", StringArgumentType.word()).executes(c -> {
                Settings.get().color = StringArgumentType.getString(c, "hex"); Settings.save();
                say(c.getSource(), "Màu: #" + Settings.get().color.replace("#", "")); return 1; })))
            // /lyrics <spotify link>   (literals above win when the word matches)
            .then(argument("url", StringArgumentType.greedyString()).executes(c -> {
                load(c.getSource(), StringArgumentType.getString(c, "url")); return 1; })));
    }

    private static int mode(FabricClientCommandSource src, String m) {
        Settings.get().mode = m; Settings.save(); say(src, "Chế độ: " + m); return 1;
    }

    private static void say(FabricClientCommandSource src, String msg) {
        src.sendFeedback(Component.literal("[Lyrics] " + msg));
    }

    private static void load(FabricClientCommandSource src, String input) {
        String id = SpotifyLink.trackId(input);
        if (id == null) { say(src, "Link không hợp lệ. Dán link bài hát dạng open.spotify.com/track/..."); return; }
        say(src, "Đang tìm lời bài hát...");
        CompletableFuture.supplyAsync(() -> {
            try {
                TrackInfo t = SpotifyMeta.fetch(id);
                List<Lrc.Line> lines = Lrc.parse(LrcLib.findSynced(t));
                if (lines.isEmpty()) throw new Exception("Lời bài hát trống");
                return new Result(t, lines);
            } catch (Exception e) { throw new RuntimeException(e.getMessage(), e); }
        }).whenComplete((res, err) -> Minecraft.getInstance().execute(() -> {
            if (err != null) {
                Throwable root = err.getCause() != null ? err.getCause() : err;
                say(src, "Lỗi: " + root.getMessage());
                return;
            }
            LyricsState.load(res.track().title() + " - " + res.track().artist(), res.lines());
            say(src, "Đang hiện: " + LyricsState.title()
                + ". Bấm phát bài này trong Spotify ngay lúc này. Lệch thì dùng /lyrics seek <giây> hoặc /lyrics offset <giây>.");
        }));
    }
}
