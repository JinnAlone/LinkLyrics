package com.linklyrics.client;

import com.linklyrics.core.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;

/** Resolves a Spotify link to synced lyrics in the background and starts the clock. */
public final class LyricsLoader {
    private record Result(TrackInfo track, List<Lrc.Line> lines) {}

    private LyricsLoader() {}

    /** `say` is always called on the game thread. */
    public static void load(String input, Consumer<String> say) {
        String id = SpotifyLink.trackId(input);
        if (id == null) { say.accept("Link không hợp lệ. Dán link bài hát dạng open.spotify.com/track/..."); return; }
        say.accept("Đang tìm lời bài hát...");
        CompletableFuture.supplyAsync(() -> {
            try {
                TrackInfo t = SpotifyMeta.fetch(id);
                List<Lrc.Line> lines = Lrc.parse(LrcLib.findSynced(t));
                if (lines.isEmpty()) throw new Exception("Lời bài hát trống");
                return new Result(t, lines);
            } catch (Exception e) { throw new RuntimeException(e.getMessage(), e); }
        }).whenComplete((res, err) -> Minecraft.getInstance().execute(() -> {
            if (err != null) {
                Throwable root = err.getCause() != null ? err.getCause() : err;
                say.accept("Lỗi: " + root.getMessage());
                return;
            }
            LyricsState.load(res.track().title() + " - " + res.track().artist(), res.lines());
            say.accept("Đang hiện: " + LyricsState.title()
                + ". Bấm phát bài này trong Spotify ngay lúc này.");
        }));
    }
}
