package com.linklyrics.client;

import net.minecraft.client.gui.screens.Screen;

final class AnimationScreen extends PanelScreen {
    private static final double[] SPEED = {0.6, 1.0, 1.6};
    private static final String[] SPEED_N = {"Chậm", "Vừa", "Nhanh"};
    private static final double[] BOB = {0, 0.5, 1.0, 2.0};
    private static final String[] BOB_N = {"Tắt", "Nhẹ", "Vừa", "Mạnh"};

    AnimationScreen(Screen parent) { super("Animation", parent); }

    @Override
    protected String status() { return "Hiệu ứng chuyển động của lời bài hát"; }

    @Override
    protected void buildButtons() {
        Settings s = Settings.get();
        cycle(leftX(), rowY(0), () -> "Từng chữ: " + (s.karaoke ? "BẬT" : "TẮT"), () -> s.karaoke = !s.karaoke);
        cycle(rightX(), rowY(0), () -> "Tia lửa: " + (s.sparks ? "BẬT" : "TẮT"), () -> s.sparks = !s.sparks);
        cycle(leftX(), rowY(1), () -> "Tốc độ hiện: " + SPEED_N[nearest(SPEED, s.speed)],
            () -> s.speed = SPEED[(nearest(SPEED, s.speed) + 1) % SPEED.length]);
        cycle(rightX(), rowY(1), () -> "Bồng bềnh: " + BOB_N[nearest(BOB, s.bob)],
            () -> s.bob = BOB[(nearest(BOB, s.bob) + 1) % BOB.length]);
    }
}
