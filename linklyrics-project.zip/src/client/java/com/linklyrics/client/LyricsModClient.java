package com.linklyrics.client;

import com.linklyrics.LyricsMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;

public class LyricsModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		Settings.get();
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> LyricsCommands.register(dispatcher));
		HudElementRegistry.addLast(LyricsMod.id("lyrics"), new LyricsView());
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (LyricsCommands.openGui) {
				LyricsCommands.openGui = false;
				client.setScreen(new LyricsScreen(null));
			}
		});
	}
}
