package com.linklyrics.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.linklyrics.core.LyricsState;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

public final class Settings {
    /** "world", "hud" or "both" */
    public String mode = "both";
    /** "default" or a font id such as "minecraft:uniform" or "lyrics-mod:custom" */
    public String font = "default";
    public double scale = 1.0;
    public String color = "FFFFFF";
    public double offset = 0;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Settings inst;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("linklyrics.json"); }

    public static Settings get() {
        if (inst == null) {
            try {
                inst = GSON.fromJson(Files.readString(file()), Settings.class);
            } catch (Exception e) { /* first run or bad file */ }
            if (inst == null) inst = new Settings();
            LyricsState.offset = inst.offset;
        }
        return inst;
    }

    public static void save() {
        try {
            get().offset = LyricsState.offset;
            Files.writeString(file(), GSON.toJson(get()));
        } catch (Exception ignored) {}
    }

    public boolean showWorld() { return !"hud".equals(mode); }
    public boolean showHud() { return !"world".equals(mode); }

    public int rgb() {
        try { return Integer.parseInt(color.replace("#", ""), 16) & 0xFFFFFF; }
        catch (NumberFormatException e) { return 0xFFFFFF; }
    }
}
