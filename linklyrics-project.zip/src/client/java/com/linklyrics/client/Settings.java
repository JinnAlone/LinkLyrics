package com.linklyrics.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.linklyrics.core.LyricsState;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

public final class Settings {
    public boolean enabled = true;
    /** "world", "hud" or "both" */
    public String mode = "both";
    /** "default" or a font id: lyrics-mod:smooth / lyrics-mod:elegant / lyrics-mod:impact */
    public String font = "lyrics-mod:smooth";
    public String preset = "smooth";
    public double scale = 1.0;
    public String color = "FFFFFF";
    public String accent = "FF9ECF";
    public double offset = 0;
    public boolean karaoke = true;
    public boolean sparks = true;
    public boolean glow = true;
    /** entrance animation speed multiplier */
    public double speed = 1.0;
    /** floating amount multiplier (0 = still) */
    public double bob = 1.0;
    /** distance of world lyrics from the player, in blocks */
    public double distance = 4.0;
    /** vertical position of HUD lyrics (fraction of screen height) */
    public double hudY = 0.74;
    /** glass frame around the settings screens */
    public boolean glass = true;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Settings inst;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("linklyrics.json"); }

    public static Settings get() {
        if (inst == null) {
            try { inst = GSON.fromJson(Files.readString(file()), Settings.class); }
            catch (Exception e) { /* first run or unreadable file */ }
            if (inst == null) inst = new Settings();
            LyricsState.offset = inst.offset;
        }
        return inst;
    }

    public static void save() {
        try {
            get().offset = LyricsState.offset;
            Files.writeString(file(), GSON.toJson(get()));
        } catch (Exception ignored) {}
    }

    public boolean showWorld() { return !"hud".equals(mode); }
    public boolean showHud() { return !"world".equals(mode); }
    public int rgb() { return parse(color, 0xFFFFFF); }
    public int accentRgb() { return parse(accent, 0xFF9ECF); }

    private static int parse(String hex, int fallback) {
        try { return Integer.parseInt(hex.replace("#", ""), 16) & 0xFFFFFF; }
        catch (Exception e) { return fallback; }
    }

    public void applyPreset(String name) {
        preset = name;
        switch (name) {
            case "calm" -> { karaoke = false; sparks = false; glow = true; speed = 0.6; bob = 0.6; font = "lyrics-mod:elegant"; }
            case "impact" -> { karaoke = true; sparks = true; glow = true; speed = 1.6; bob = 0.4; font = "lyrics-mod:impact"; }
            case "minimal" -> { karaoke = false; sparks = false; glow = false; speed = 1.0; bob = 0.3; font = "default"; }
            default -> { preset = "smooth"; karaoke = true; sparks = true; glow = true; speed = 1.0; bob = 1.0; font = "lyrics-mod:smooth"; }
        }
    }
}
