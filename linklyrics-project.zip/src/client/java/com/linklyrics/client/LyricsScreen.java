package com.linklyrics.client;

import com.linklyrics.core.LyricsState;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Main settings screen (opened with /lyrics). */
public final class LyricsScreen extends PanelScreen {
    private static final String[] PRESETS = {"smooth", "calm", "impact", "minimal"};
    private Button playBtn;

    public LyricsScreen(net.minecraft.client.gui.screens.Screen parent) {
        super("Link Lyrics", parent);
    }

    @Override
    protected String status() {
        return LyricsState.title().isEmpty()
            ? "Chưa có bài hát. Vào Spotify... để dán link."
            : "Đang hiện: " + LyricsState.title();
    }

    @Override
    protected void buildButtons() {
        Settings s = Settings.get();
        int w = colW(), lx = leftX(), rx = rightX();

        cycle(lx, rowY(0), () -> "Lời: " + (s.enabled ? "BẬT" : "TẮT"), () -> s.enabled = !s.enabled);
        playBtn = add(playLabel(), rx, rowY(0), w, b -> {
            if (LyricsState.running()) LyricsState.pause(); else LyricsState.resume();
            b.setMessage(Component.literal(playLabel()));
        });

        cycle(lx, rowY(1), () -> "Preset: " + cap(s.preset), () -> {
            int i = 0;
            for (int k = 0; k < PRESETS.length; k++) if (PRESETS[k].equals(s.preset)) i = k;
            s.applyPreset(PRESETS[(i + 1) % PRESETS.length]);
        });
        add("Dừng và xóa lời", rx, rowY(1), w, b -> LyricsState.stop());

        add("Tua -5 giây", lx, rowY(2), w, b -> LyricsState.seek(LyricsState.position() - LyricsState.offset - 5));
        add("Tua +5 giây", rx, rowY(2), w, b -> LyricsState.seek(LyricsState.position() - LyricsState.offset + 5));

        add("Lệch -0.1s", lx, rowY(3), w, b -> { LyricsState.offset -= 0.1; Settings.save(); });
        add("Lệch +0.1s", rx, rowY(3), w, b -> { LyricsState.offset += 0.1; Settings.save(); });

        add("Animation...", lx, rowY(4), w, b -> this.minecraft.gui.setScreen(new AnimationScreen(this)));
        add("Placement...", rx, rowY(4), w, b -> this.minecraft.gui.setScreen(new PlacementScreen(this)));
        add("Colours and effects...", lx, rowY(5), w, b -> this.minecraft.gui.setScreen(new ColoursScreen(this)));
        add("Spotify link...", rx, rowY(5), w, b -> this.minecraft.gui.setScreen(new SpotifyScreen(this)));
    }

    /** Style toggle sits at the bottom-left, next to Done. */
    @Override
    protected void addDone() {
        cycle(leftX(), bottomY(), () -> "Style: " + (Settings.get().glass ? "Glass" : "Vanilla"),
            () -> Settings.get().glass = !Settings.get().glass);
        super.addDone();
    }

    private static String playLabel() { return LyricsState.running() ? "Tạm dừng" : "Phát tiếp"; }
    private static String cap(String s) { return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1); }
}
