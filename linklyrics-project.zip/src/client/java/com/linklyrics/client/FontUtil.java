package com.linklyrics.client;

import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

/** The only place that touches font/Style APIs, so it is easy to fix if 26.2 names differ. */
public final class FontUtil {
    private static String cachedKey = "";
    private static Style cached = Style.EMPTY;

    private FontUtil() {}

    public static Style style() {
        String f = Settings.get().font;
        if (f == null || f.isBlank() || f.equals("default")) return Style.EMPTY;
        if (!f.equals(cachedKey)) {
            Identifier id = Identifier.tryParse(f);
            cached = id == null ? Style.EMPTY : Style.EMPTY.withFont(new FontDescription.Resource(id));
            cachedKey = f;
        }
        return cached;
    }
}
