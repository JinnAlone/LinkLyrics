package com.linklyrics.client;

import net.minecraft.client.gui.screens.Screen;

final class ColoursScreen extends PanelScreen {
    private static final String[] HEX = {"FFFFFF", "FF9ECF", "7DF9FF", "FFD166", "C3A6FF", "9BF6B4", "FF6B6B"};
    private static final String[] NAME = {"Trắng", "Hồng", "Xanh ngọc", "Vàng", "Tím", "Xanh lá", "Đỏ"};
    private static final String[] FONT = {"lyrics-mod:smooth", "lyrics-mod:elegant", "lyrics-mod:impact", "default"};
    private static final String[] FONT_N = {"Smooth", "Elegant", "Impact", "Mặc định"};

    ColoursScreen(Screen parent) { super("Colours and effects", parent); }

    @Override
    protected String status() { return "Màu, font và hiệu ứng sáng"; }

    private static int idx(String[] list, String v) {
        for (int i = 0; i < list.length; i++) if (list[i].equalsIgnoreCase(v)) return i;
        return -1;
    }

    private static String colorName(String hex) {
        int i = idx(HEX, hex.replace("#", ""));
        return i >= 0 ? NAME[i] : "#" + hex;
    }

    @Override
    protected void buildButtons() {
        Settings s = Settings.get();
        cycle(leftX(), rowY(0), () -> "Màu chữ: " + colorName(s.color),
            () -> s.color = HEX[(idx(HEX, s.color.replace("#", "")) + 1) % HEX.length]);
        cycle(rightX(), rowY(0), () -> "Màu nhấn: " + colorName(s.accent),
            () -> s.accent = HEX[(idx(HEX, s.accent.replace("#", "")) + 1) % HEX.length]);
        cycle(leftX(), rowY(1), () -> "Font: " + (idx(FONT, s.font) >= 0 ? FONT_N[idx(FONT, s.font)] : s.font),
            () -> s.font = FONT[(idx(FONT, s.font) + 1) % FONT.length]);
        cycle(rightX(), rowY(1), () -> "Phát sáng: " + (s.glow ? "BẬT" : "TẮT"), () -> s.glow = !s.glow);
    }
}
