# Link Lyrics (Fabric, Minecraft 26.2)

Dán link bài hát Spotify -> lời đồng bộ hiện quanh bạn trong thế giới game và/hoặc trên HUD.

## Lệnh (gõ trong chat)
- `/lyrics <link Spotify>`  tải lời và bắt đầu chạy đồng hồ từ 0:00
- `/lyrics pause | resume | stop`
- `/lyrics seek <giây>`  tua;  `/lyrics offset <giây>`  chỉnh lệch (+ = hiện sớm hơn)
- `/lyrics mode world|hud|both`
- `/lyrics font default | minecraft:uniform | lyrics-mod:custom`
- `/lyrics scale <0.3-4>`,  `/lyrics color <hex, vd FFAACC>`

Link không cho biết bài đang phát tới giây nào, nên mod tự đếm giờ: phát bài trong Spotify
cùng lúc bạn chạy lệnh, rồi chỉnh bằng `seek`/`offset` nếu lệch.

## Font tuỳ chỉnh (TTF)
1. Tạo `src/client/resources/assets/lyrics-mod/font/custom.ttf` (dùng font có license cho phép).
2. Tạo `src/client/resources/assets/lyrics-mod/font/custom.json`:
   `{"providers":[{"type":"ttf","file":"lyrics-mod:custom.ttf","size":11.0,"oversample":8.0}]}`
3. Trong game: `/lyrics font lyrics-mod:custom`. Font có sẵn của game: `minecraft:uniform`, `minecraft:alt`.

## Build
Mod này CHƯA được biên dịch trên Minecraft 26.2 (môi trường tạo ra nó không có Minecraft/Fabric).
1. Tạo project mẫu cho 26.2 tại https://fabricmc.net/develop (tick "split client sources").
2. Chép `src/` của thư mục này vào project mẫu (gộp `fabric.mod.json`, sửa `version`/`depends` cho khớp).
3. `./gradlew build` (cần JDK 25) -> file jar trong `build/libs/`.
4. Nếu báo lỗi tên class/hàm, chỉ cần sửa ở: `FontUtil` (font), `LyricsView` (vẽ chữ/HUD/ma trận 2D),
   `LinkLyricsClient` (đăng ký HUD), `LyricsCommands` (lệnh). Phần `core/` không phụ thuộc Minecraft.

## Giao diện (v2)
Gõ `/lyrics` để mở màn hình cài đặt: Preset, Animation..., Placement..., Colours and effects..., Spotify link..., Style (Glass/Vanilla).

## Giấy phép font
Các font trong `assets/lyrics-mod/font` (Hanken Grotesk, Poppins, và một bản Lora đổi tên) dùng giấy phép SIL OFL 1.1.
Văn bản giấy phép nằm trong `assets/lyrics-mod/licenses`.
